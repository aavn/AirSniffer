#ifndef _REST_UTIL_STAGING_H
#define _REST_UTIL_STAGING_H
#include <Sniffer_Data_Util.h>

bool saveData_staging(Environment * envirData, RestProperty * restProperty);
#endif
