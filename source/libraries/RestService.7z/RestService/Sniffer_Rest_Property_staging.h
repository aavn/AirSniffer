#ifndef _REST_PROPERTY_STAGING_H
#define _REST_PROPERTY_STAGING_H
#include <SPI.h>
#include <Sniffer_Rest_Constant.h>

#define serverAddress_staging "192.168.70.91"
#define snifferUrl_staging "/api/pollutantvalues"
#define serverPort_staging 8080



#endif
